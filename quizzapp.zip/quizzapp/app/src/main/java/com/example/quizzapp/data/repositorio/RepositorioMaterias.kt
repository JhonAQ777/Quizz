package com.example.quizzapp.data.repositorio

import com.example.quizzapp.data.modelo.Materia
import com.example.quizzapp.data.remoto.ClienteSupabase
import io.github.jan.supabase.postgrest.from

/**
 * Busca a lista de matérias (Física, História, Português, Matemática...)
 * direto da tabela "materias". Quando você cadastrar matérias novas no
 * banco, elas aparecem aqui automaticamente — sem precisar mexer no app
 * (a TelaPrincipal já sabe lidar com matérias "novas" sem estilo definido,
 * veja EstiloDisciplina.kt).
 */
class RepositorioMaterias {

    private val supabase = ClienteSupabase.instancia

    suspend fun buscarTodas(): Result<List<Materia>> {
        return try {
            val materias = supabase
                .from("materias")
                .select()
                .decodeList<Materia>()

            Result.success(materias)
        } catch (erro: Exception) {
            Result.failure(erro)
        }
    }
}
