package com.example.quizzapp




import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.example.quizzapp.navegacao.GrafoNavegacao
import com.example.quizzapp.ui.theme.TemaQuizzApp

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        enableEdgeToEdge()

        setContent {

            TemaQuizzApp {

                Surface(
                    modifier = Modifier.fillMaxSize()
                ) {

                    // GrafoNavegacao controla qual tela aparece
                    // (Login -> CriarConta -> Principal). Veja
                    // navegacao/GrafoNavegacao.kt.

                    GrafoNavegacao()
                }
            }
        }
    }
}
