import java.util.Properties

plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.compose)
    alias(libs.plugins.kotlin.serialization)
}

// Lê as credenciais do Supabase de local.properties (arquivo que NUNCA vai pro Git).
// Assim a URL e a chave não ficam expostas no código-fonte.
val propriedadesLocais = Properties().apply {
    val arquivo = rootProject.file("local.properties")
    if (arquivo.exists()) {
        load(arquivo.inputStream())
    }
}

android {
    namespace = "com.example.quizzapp"
    compileSdk {
        version = release(37) {
            minorApiLevel = 1
        }
    }

    defaultConfig {
        applicationId = "com.example.quizzapp"
        minSdk = 24
        targetSdk = 36
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"

        // Gera BuildConfig.SUPABASE_URL e BuildConfig.SUPABASE_KEY a partir
        // do local.properties. Se as chaves não existirem lá, fica vazio
        // e o app avisa no Logcat em vez de quebrar o build.
        buildConfigField(
            "String",
            "SUPABASE_URL",
            "\"${propriedadesLocais.getProperty("SUPABASE_URL", "")}\""
        )
        buildConfigField(
            "String",
            "SUPABASE_KEY",
            "\"${propriedadesLocais.getProperty("SUPABASE_KEY", "")}\""
        )
    }

    buildTypes {
        release {
            optimization {
                enable = false
            }
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }
    buildFeatures {
        compose = true
        buildConfig = true
    }
}

dependencies {
    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.activity.compose)
    implementation(libs.androidx.compose.material3)
    implementation(libs.androidx.compose.ui)
    implementation(libs.androidx.compose.ui.graphics)
    implementation(libs.androidx.compose.ui.tooling.preview)
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.lifecycle.runtime.ktx)
    testImplementation(libs.junit)
    androidTestImplementation(platform(libs.androidx.compose.bom))
    androidTestImplementation(libs.androidx.compose.ui.test.junit4)
    androidTestImplementation(libs.androidx.espresso.core)
    androidTestImplementation(libs.androidx.junit)
    debugImplementation(libs.androidx.compose.ui.test.manifest)
    debugImplementation(libs.androidx.compose.ui.tooling)

    //dependencias implementadas
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.7")
    implementation("androidx.compose.material:material-icons-extended:1.7.6")

    // Navegação entre telas.
    implementation(libs.androidx.navigation.compose)

    // Supabase: Auth (login/cadastro) e Postgrest (consultas ao banco).
    implementation(platform(libs.supabase.bom))
    implementation(libs.supabase.auth)
    implementation(libs.supabase.postgrest)
    implementation(libs.ktor.client.android)

    // Necessário para o Supabase (des)serializar dados em JSON.
    implementation(libs.kotlinx.serialization.json)



    val supabaseVersion = "3.1.4" // revisa la última versión en github.com/supabase-community/supabase-kt

    implementation(platform("io.github.jan-tennert.supabase:bom:$supabaseVersion"))
    implementation("io.github.jan-tennert.supabase:postgrest-kt")
    implementation("io.github.jan-tennert.supabase:auth-kt")

    // Cliente HTTP que supabase-kt necesita (Ktor)
    implementation("io.ktor:ktor-client-android:3.0.3")

    // Ya deberías tener esto para el proyecto (según lo que veníamos armando)
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.7")
}


