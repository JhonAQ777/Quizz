package com.example.quizzapp.ui.screens.principal.componentes

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Pets
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

import com.example.quizzapp.ui.theme.BordaCampoLogin
import com.example.quizzapp.ui.theme.CampoFundoLogin
import com.example.quizzapp.ui.theme.RoxoPrincipal
import com.example.quizzapp.ui.theme.TextoRotuloLogin
import com.example.quizzapp.ui.theme.TextoTituloPrincipal

/**
 * Cabeçalho da TelaPrincipal: avatar + "Bem-vindo de volta, Olá, {nome}!".
 *
 * O avatar da raposa é uma ilustração — recurso externo.
 * Coloque o arquivo em res/drawable/ic_raposa.png e troque o Icon abaixo
 * por Image(painter = painterResource(R.drawable.ic_raposa), ...).
 * Por enquanto usamos um ícone padrão como placeholder.
 */
@Composable
fun CabecalhoBoasVindas(
    nomeUsuario: String,
    modificador: Modifier = Modifier
) {
    Row(
        modifier = modificador,
        verticalAlignment = Alignment.CenterVertically
    ) {

        Box(
            modifier = Modifier
                .size(56.dp)
                .clip(RoundedCornerShape(14.dp))
                .background(CampoFundoLogin)
                .border(2.dp, BordaCampoLogin, RoundedCornerShape(14.dp)),
            contentAlignment = Alignment.Center
        ) {
            // Placeholder do avatar. Troque por Image(...) com ic_raposa.png.
            Icon(
                imageVector = Icons.Filled.Pets,
                contentDescription = "Avatar",
                tint = RoxoPrincipal
            )
        }

        Column(modifier = Modifier.padding(start = 12.dp)) {

            Text(
                text = "Bem-vindo de volta,",
                color = TextoRotuloLogin,
                fontSize = 13.sp
            )

            Text(
                text = "Olá, $nomeUsuario!",
                color = TextoTituloPrincipal,
                fontSize = 22.sp,
                fontWeight = FontWeight.ExtraBold
            )
        }
    }
}
