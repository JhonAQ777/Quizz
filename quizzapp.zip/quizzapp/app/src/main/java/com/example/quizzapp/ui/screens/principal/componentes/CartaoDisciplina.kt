package com.example.quizzapp.ui.screens.principal.componentes

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

import com.example.quizzapp.ui.theme.TextoBranco
import com.example.quizzapp.ui.theme.TextoRotuloLogin
import com.example.quizzapp.ui.theme.TextoTituloPrincipal

/**
 * Cartão de uma matéria. Um único componente serve pra todas as
 * matérias — a cor/ícone vem de EstiloDisciplina.kt, então adicionar
 * uma matéria nova no banco não exige criar um cartão novo.
 *
 * aoClicar ainda não leva a lugar nenhum (não temos as telas de quiz
 * ainda) — já vem pronto pra receber a navegação real depois.
 */

@Composable
fun CartaoDisciplina(
    titulo: String,
    descricao: String,
    estilo: EstiloDisciplina,
    aoClicar: () -> Unit,
    modificador: Modifier = Modifier
) {
    Box(
        modifier = modificador
            .clip(RoundedCornerShape(18.dp))
            .background(estilo.corFundo)
            .clickable { aoClicar() }
            .padding(16.dp)
    ) {
        Column {

            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(estilo.cor),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = estilo.icone,
                    contentDescription = titulo,
                    tint = TextoBranco
                )
            }

            Spacer(Modifier.height(12.dp))

            Text(
                text = titulo.uppercase(),
                color = TextoTituloPrincipal,
                fontSize = 15.sp,
                fontWeight = FontWeight.ExtraBold
            )

            Spacer(Modifier.height(4.dp))

            Text(
                text = descricao,
                color = TextoRotuloLogin,
                fontSize = 12.sp
            )

            Spacer(Modifier.height(12.dp))

            Box(
                modifier = Modifier
                    .size(32.dp)
                    .clip(CircleShape)
                    .background(estilo.cor),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                    contentDescription = null,
                    tint = TextoBranco,
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}

