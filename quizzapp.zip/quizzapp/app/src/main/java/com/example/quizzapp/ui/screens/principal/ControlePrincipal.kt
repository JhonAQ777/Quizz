package com.example.quizzapp.ui.screens.principal

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.quizzapp.data.modelo.Materia
import com.example.quizzapp.data.repositorio.RepositorioMaterias
import com.example.quizzapp.data.repositorio.RepositorioPerfil
import kotlinx.coroutines.launch

/** Estado da UI da tela principal. Apenas dados, sem lógica de negócio. */
data class EstadoPrincipal(
    val nomeUsuario: String = "Aluno",
    val materias: List<Materia> = emptyList(),
    val carregando: Boolean = true
)

/**
 * ViewModel da tela principal.
 * Busca o nome do usuário logado e a lista de matérias no Supabase
 * assim que a tela abre (veja carregarDados()).
 */
class ControlePrincipal(
    private val repositorioPerfil: RepositorioPerfil = RepositorioPerfil(),
    private val repositorioMaterias: RepositorioMaterias = RepositorioMaterias()
) : ViewModel() {

    var estadoTela by mutableStateOf(EstadoPrincipal())
        private set

    init {
        carregarDados()
    }

    private fun carregarDados() {
        viewModelScope.launch {

            // Busca o nome do usuário. Se der erro (ex: RLS não configurada
            // ainda), mantém "Aluno" como nome padrão em vez de travar a tela.
            repositorioPerfil.buscarPerfilAtual()
                .onSuccess { perfil ->
                    estadoTela = estadoTela.copy(nomeUsuario = perfil.nome_usuario)
                }

            // Busca as matérias cadastradas.
            repositorioMaterias.buscarTodas()
                .onSuccess { materias ->
                    estadoTela = estadoTela.copy(materias = materias)
                }

            estadoTela = estadoTela.copy(carregando = false)
        }
    }
}
