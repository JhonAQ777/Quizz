package com.example.quizzapp.ui.theme




import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable


// O app inteiro usa um visual claro (fundo creme, textos escuros),
// então o esquema de cores é fixo em modo claro — sem depender do
// tema claro/escuro do sistema.

private val EsquemaCoresQuizzApp = lightColorScheme(

    primary = RoxoPrincipal,

    secondary = BotaoEntrarFundo,

    background = FundoLogin,

    surface = CampoFundoLogin,

    onPrimary = TextoBranco,

    onBackground = TextoCampoLogin,

    onSurface = TextoCampoLogin
)


@Composable
fun TemaQuizzApp(
    conteudo: @Composable () -> Unit
) {

    MaterialTheme(

        colorScheme = EsquemaCoresQuizzApp,

        typography = MaterialTheme.typography,

        // Se você tiver uma fonte personalizada em estilo pixelado
        // (a usada em "DISCIPLINAS", "DESAFIO DO DIA" etc.),
        // defina-a aqui em Type.kt.

        content = conteudo
    )
}
