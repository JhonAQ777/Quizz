package com.example.quizzapp.ui.theme


import androidx.compose.ui.graphics.Color


// ---- Fundo ----

val FundoEscuro = Color(0xFF0A0E27) // Azul-marinho muito escuro, base do fundo.

val BrilhoFundo = Color(0xFF1A0B3D) // Roxo escuro para o brilho inferior (se o fundo for montado com Compose).


// ---- Roxos / violeta (marca, bordas, "INSTITUTIONAL") ----

val RoxoPrincipal = Color(0xFF8B5CF6)

val RoxoClaro = Color(0xFFB794F6)

val BordaRoxa = Color(0xFF6D4AAE) // Borda dos campos de texto.


// ---- Verde/turquesa ("QUIZ") ----

val VerdeInicio = Color(0xFF34D399)

val VerdeFinal = Color(0xFF22D3EE)


// ---- Botão e links (rosa/magenta) ----

val RosaDestaque = Color(0xFFD946EF)

val InicioBotao = Color(0xFF7C3AED) // Início do gradiente do botão "Log In".

val FinalBotao = Color(0xFFD946EF) // Final do gradiente do botão "Log In".


// ---- Campos de texto ----

val FundoCampo = Color(0xFF141A3D)

val BordaCampoInativo = Color(0xFF3D3670)


// ---- Textos ----

val TextoBranco = Color(0xFFFFFFFF)

val TextoBrancoSuave = Color(0xCCFFFFFF) // Branco com ~80% de opacidade, para subtítulos.

val TextoBrancoFraco = Color(0x99FFFFFF) // Branco suave, para o divisor "OR".


// ============================================================
// Cores da NOVA tela de login (fundo claro/creme).
// Estas substituem as cores usadas na tela de login antiga
// (RoxoPrincipal, FundoEscuro etc. continuam existindo porque
// ainda são usadas no tema geral do app, em Tema.kt).
// ============================================================

val FundoLogin = Color(0xFFFFFFFF) // Fundo creme/pêssego da tela.

val TextoRotuloLogin = Color(0xFF9C8558) // Cor dos rótulos "EMAIL" / "PASSWORD".

val BordaCampoLogin = Color(0xFF201C3D) // Borda escura dos campos e botões.

val CampoFundoLogin = Color(0xFFFFFFFF) // Fundo branco dos campos de texto.

val IconeCampoLogin = Color(0xFF9C8558) // Cor dos ícones de envelope/cadeado/olho.

val TextoCampoLogin = Color(0xFF201C3D) // Cor do texto digitado nos campos.

val TextoPlaceholderLogin = Color(0xFFB7B3C9) // Cor do texto de exemplo ("name@example.com").

val BotaoEntrarFundo = Color(0xFFF7911E) // Fundo laranja do botão "LOG IN".

val TextoBotaoEntrar = Color(0xFFFFFFFF) // Texto branco do botão "LOG IN".

val BotaoCriarContaFundo = Color(0xFFFFFFFF) // Fundo branco do botão "CREATE ACCOUNT".

val TextoBotaoCriarConta = Color(0xFF201C3D) // Texto escuro do botão "CREATE ACCOUNT".

val TextoErroLogin = Color(0xFFD64545) // Cor da mensagem de erro.


// ============================================================
// Cores da TelaPrincipal (menu com as disciplinas).
// Reaproveita FundoLogin como fundo (mesmo tom creme do app todo).
// ============================================================

val TextoTituloPrincipal = Color(0xFF201C3D) // Títulos escuros ("DISCIPLINAS", "Olá, Aluno!").

val TextoSubtituloPrincipal = Color(0xFF6B6580) // Texto secundário mais claro.

val CorFisica = Color(0xFF2F6FE0)
val CorFundoFisica = Color(0xFFEAF1FF)

val CorHistoria = Color(0xFFE8963C)
val CorFundoHistoria = Color(0xFFFFF3E4)

val CorPortugues = Color(0xFFD94B3E)
val CorFundoPortugues = Color(0xFFFDECEA)

val CorMatematica = Color(0xFF3C9F5F)
val CorFundoMatematica = Color(0xFFEAF7EE)

val CorDisciplinaPadrao = Color(0xFF6B6580) // Estilo neutro para matérias novas sem cor definida ainda.
val CorFundoDisciplinaPadrao = Color(0xFFF0EFF5)

