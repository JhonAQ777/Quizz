package com.example.quizzapp.data.remoto

import com.example.quizzapp.BuildConfig
import io.github.jan.supabase.auth.Auth
import io.github.jan.supabase.createSupabaseClient
import io.github.jan.supabase.postgrest.Postgrest

/**
 * Instância única (singleton) do cliente Supabase.
 *
 * A URL e a chave vêm do BuildConfig, que por sua vez lê o arquivo
 * local.properties (veja app/build.gradle.kts). Isso evita deixar
 * credenciais escritas direto no código-fonte.
 *
 * 🔒 Se SUPABASE_URL ou SUPABASE_KEY estiverem vazios, é porque falta
 * configurar o local.properties (veja a explicação enviada junto com
 * este código).
 */
object ClienteSupabase {

    val instancia = createSupabaseClient(
        supabaseUrl = BuildConfig.SUPABASE_URL,
        supabaseKey = BuildConfig.SUPABASE_KEY
    ) {
        install(Auth)
        install(Postgrest)
    }
}
