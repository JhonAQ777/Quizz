package com.example.quizzapp.ui.screens.criarconta

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.quizzapp.data.repositorio.RepositorioAutenticacao
import kotlinx.coroutines.launch

/** Estado da UI da tela de criar conta. Apenas dados, sem lógica de negócio. */
data class EstadoCriarConta(
    val nome: String = "",
    val email: String = "",
    val senha: String = "",
    val confirmarSenha: String = "",
    val senhaVisivel: Boolean = false,
    val confirmarSenhaVisivel: Boolean = false,
    val carregando: Boolean = false,
    val mensagemErro: String? = null
)

/**
 * ViewModel da tela de criar conta.
 * Já conectado ao Supabase Auth via RepositorioAutenticacao.
 *
 * Não faz login automático depois de cadastrar: só chama aoSucesso(),
 * e quem decide o que fazer é a TelaCriarConta / GrafoNavegacao
 * (nesse caso, voltar pra tela de login).
 */
class ControleCriarConta(
    private val repositorioAutenticacao: RepositorioAutenticacao = RepositorioAutenticacao()
) : ViewModel() {

    var estadoTela by mutableStateOf(EstadoCriarConta())
        private set

    fun alterarNome(novoNome: String) {
        estadoTela = estadoTela.copy(nome = novoNome, mensagemErro = null)
    }

    fun alterarEmail(novoEmail: String) {
        estadoTela = estadoTela.copy(email = novoEmail, mensagemErro = null)
    }

    fun alterarSenha(novaSenha: String) {
        estadoTela = estadoTela.copy(senha = novaSenha, mensagemErro = null)
    }

    fun alterarConfirmarSenha(novoValor: String) {
        estadoTela = estadoTela.copy(confirmarSenha = novoValor, mensagemErro = null)
    }

    fun alternarVisibilidadeSenha() {
        estadoTela = estadoTela.copy(senhaVisivel = !estadoTela.senhaVisivel)
    }

    fun alternarVisibilidadeConfirmarSenha() {
        estadoTela = estadoTela.copy(confirmarSenhaVisivel = !estadoTela.confirmarSenhaVisivel)
    }

    /**
     * Valida os campos e cadastra a conta no Supabase.
     * Em caso de sucesso, chama aoSucesso() (a TelaCriarConta usa isso
     * pra voltar pro login, veja GrafoNavegacao.kt).
     */
    fun cadastrar(aoSucesso: () -> Unit) {

        val estado = estadoTela

        if (estado.nome.isBlank() || estado.email.isBlank() ||
            estado.senha.isBlank() || estado.confirmarSenha.isBlank()
        ) {
            estadoTela = estado.copy(mensagemErro = "Please fill in all fields.")
            return
        }

        if (estado.senha != estado.confirmarSenha) {
            estadoTela = estado.copy(mensagemErro = "Passwords do not match.")
            return
        }

        if (estado.senha.length < 6) {
            estadoTela = estado.copy(mensagemErro = "Password must be at least 6 characters.")
            return
        }

        estadoTela = estado.copy(carregando = true, mensagemErro = null)

        viewModelScope.launch {

            val resultado = repositorioAutenticacao.cadastrar(
                nome = estado.nome,
                email = estado.email,
                senha = estado.senha
            )

            estadoTela = estadoTela.copy(carregando = false)

            resultado
                .onSuccess {
                    aoSucesso()
                }
                .onFailure { erro ->
                    estadoTela = estadoTela.copy(
                        mensagemErro = erro.message ?: "Could not create account. Please try again."
                    )
                }
        }
    }
}
