package com.example.quizzapp.ui.screens.principal.componentes

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Science
import androidx.compose.material.icons.filled.School
import androidx.compose.ui.graphics.vector.ImageVector

import com.example.quizzapp.ui.theme.CorDisciplinaPadrao
import com.example.quizzapp.ui.theme.CorFisica
import com.example.quizzapp.ui.theme.CorFundoDisciplinaPadrao
import com.example.quizzapp.ui.theme.CorFundoFisica
import com.example.quizzapp.ui.theme.CorFundoHistoria
import com.example.quizzapp.ui.theme.CorFundoMatematica
import com.example.quizzapp.ui.theme.CorFundoPortugues
import com.example.quizzapp.ui.theme.CorHistoria
import com.example.quizzapp.ui.theme.CorMatematica
import com.example.quizzapp.ui.theme.CorPortugues
import androidx.compose.ui.graphics.Color

/** Ícone + cores usados no cartão de uma matéria. */
data class EstiloDisciplina(
    val icone: ImageVector,
    val cor: Color,
    val corFundo: Color
)

/**
 * Dá um ícone e uma cor pra cada matéria pelo nome.
 *
 * Matérias que ainda não estão nesta lista (ex: as que você adicionar
 * no banco no futuro) caem no estilo padrão (cinza + ícone de escola),
 * então a tela não quebra — só fica com uma cor neutra até você
 * adicionar o estilo dela aqui.
 */
fun estiloParaMateria(nomeMateria: String): EstiloDisciplina {
    return when (nomeMateria.trim().lowercase()) {
        "física", "fisica" -> EstiloDisciplina(Icons.Filled.Science, CorFisica, CorFundoFisica)
        "história", "historia" -> EstiloDisciplina(Icons.Filled.AccountBalance, CorHistoria, CorFundoHistoria)
        "português", "portugues" -> EstiloDisciplina(Icons.Filled.MenuBook, CorPortugues, CorFundoPortugues)
        "matemática", "matematica" -> EstiloDisciplina(Icons.Filled.Calculate, CorMatematica, CorFundoMatematica)
        else -> EstiloDisciplina(Icons.Filled.School, CorDisciplinaPadrao, CorFundoDisciplinaPadrao)
    }
}
