package com.example.quizzapp.navegacao

/**
 * Nomes das rotas usadas no NavHost (GrafoNavegacao.kt).
 * Centralizar aqui evita erros de digitação ao navegar.
 */
object Rotas {
    const val LOGIN = "login"
    const val CRIAR_CONTA = "criar_conta"
    const val PRINCIPAL = "principal"
}
