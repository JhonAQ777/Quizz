package com.example.quizzapp.ui.components


import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

import com.example.quizzapp.ui.theme.BordaCampoLogin
import com.example.quizzapp.ui.theme.CampoFundoLogin
import com.example.quizzapp.ui.theme.IconeCampoLogin
import com.example.quizzapp.ui.theme.TextoCampoLogin
import com.example.quizzapp.ui.theme.TextoPlaceholderLogin
import com.example.quizzapp.ui.theme.TextoRotuloLogin


/**
 * Campo de texto com rótulo em cima (ex: "EMAIL", "PASSWORD"), fundo branco
 * e borda escura, igual ao novo design da tela de login.
 * Serve tanto para e-mail quanto para senha (com ehSenha = true).
 */

@Composable
fun CampoComRotulo(

    rotulo: String,

    valor: String,

    aoAlterarValor: (String) -> Unit,

    textoPlaceholder: String,

    iconeEsquerdo: ImageVector,

    modificador: Modifier = Modifier,

    ehSenha: Boolean = false,

    senhaVisivel: Boolean = false,

    aoAlternarVisibilidadeSenha: () -> Unit = {}

) {

    Column(modificador.fillMaxWidth()) {

        Text(
            text = rotulo,
            color = TextoRotuloLogin,
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 0.5.sp
        )

        androidx.compose.foundation.layout.Spacer(
            Modifier.height(8.dp)
        )

        OutlinedTextField(

            value = valor,

            onValueChange = aoAlterarValor,

            modifier = Modifier
                .fillMaxWidth()
                .height(60.dp),

            placeholder = {

                Text(
                    textoPlaceholder,
                    color = TextoPlaceholderLogin
                )
            },

            leadingIcon = {

                Icon(
                    iconeEsquerdo,
                    contentDescription = null,
                    tint = IconeCampoLogin
                )
            },

            trailingIcon = {

                // O ícone de olho aparece somente no campo de senha.

                if (ehSenha) {

                    IconButton(
                        onClick = aoAlternarVisibilidadeSenha
                    ) {

                        Icon(

                            imageVector =
                                if (senhaVisivel)
                                    Icons.Filled.Visibility
                                else
                                    Icons.Filled.VisibilityOff,

                            contentDescription =
                                if (senhaVisivel)
                                    "Ocultar senha"
                                else
                                    "Mostrar senha",

                            tint = IconeCampoLogin
                        )
                    }
                }
            },

            visualTransformation =
                if (ehSenha && !senhaVisivel)
                    PasswordVisualTransformation()
                else
                    VisualTransformation.None,

            keyboardOptions =
                if (ehSenha) {

                    KeyboardOptions(
                        keyboardType = KeyboardType.Password
                    )

                } else {

                    KeyboardOptions(
                        keyboardType = KeyboardType.Email
                    )
                },

            singleLine = true,

            shape = RoundedCornerShape(30.dp),

            colors = OutlinedTextFieldDefaults.colors(

                focusedContainerColor = CampoFundoLogin,

                unfocusedContainerColor = CampoFundoLogin,

                focusedBorderColor = BordaCampoLogin,

                unfocusedBorderColor = BordaCampoLogin,

                focusedTextColor = TextoCampoLogin,

                unfocusedTextColor = TextoCampoLogin,

                cursorColor = BordaCampoLogin
            )
        )
    }
}


/**
 * Botão sólido com borda escura, usado tanto para "LOG IN" (fundo laranja)
 * quanto para "CREATE ACCOUNT" (fundo branco), igual ao novo design.
 * aoClicar é onde você deverá disparar sua lógica real de login
 * (veja a observação em TelaLogin.kt / ControleLogin.kt).
 */

@Composable
fun BotaoLogin(

    texto: String,

    aoClicar: () -> Unit,

    corFundo: Color,

    corTexto: Color,

    modificador: Modifier = Modifier,

    habilitado: Boolean = true

) {

    Box(

        modifier = modificador
            .fillMaxWidth()
            .height(58.dp)

            .clip(
                RoundedCornerShape(30.dp)
            )

            .background(corFundo)

            .border(
                width = 2.dp,
                color = BordaCampoLogin,
                shape = RoundedCornerShape(30.dp)
            )

            .clickable(
                enabled = habilitado
            ) {
                aoClicar()
            },

        contentAlignment = Alignment.Center

    ) {

        Text(

            text = texto,

            color = corTexto,

            fontSize = 17.sp,

            fontWeight = FontWeight.ExtraBold,

            letterSpacing = 0.5.sp
        )
    }
}
