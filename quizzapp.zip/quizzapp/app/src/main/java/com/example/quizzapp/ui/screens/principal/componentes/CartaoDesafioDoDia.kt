package com.example.quizzapp.ui.screens.principal.componentes

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

import com.example.quizzapp.ui.theme.BotaoEntrarFundo
import com.example.quizzapp.ui.theme.RoxoPrincipal
import com.example.quizzapp.ui.theme.TextoBranco

/**
 * Cartão "Desafio do dia". Por enquanto o conteúdo (título/descrição) é
 * fixo — no futuro dá pra puxar isso da tabela "quizzes" (ex: um quiz
 * marcado como destaque do dia) e passar titulo/descricao como parâmetros
 * vindos do banco em vez de valor fixo.
 *
 * A ilustração de fundo (floresta pixelada) é um recurso externo.
 * Coloque em res/drawable/img_desafio_fundo.png e troque o Box de fundo
 * abaixo por Image(painter = painterResource(...), contentScale = Crop).
 */
@Composable
fun CartaoDesafioDoDia(
    titulo: String = "O Ecosistema",
    descricao: String = "Teste seus conhecimentos sobre a fauna e flora da floresta pixelada.",
    aoComecar: () -> Unit = {},
    modificador: Modifier = Modifier
) {
    Box(
        modifier = modificador
            .fillMaxWidth()
            .height(230.dp)
            .clip(RoundedCornerShape(20.dp))
            // Placeholder do fundo (troque pela imagem da floresta).
            .background(Color(0xFF7FB5E8))
    ) {

        Column(modifier = Modifier.fillMaxWidth()) {

            // Faixa "DESAFIO DO DIA".
            Row(
                modifier = Modifier
                    .background(RoxoPrincipal)
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Filled.EmojiEvents,
                    contentDescription = null,
                    tint = TextoBranco,
                    modifier = Modifier.width(18.dp)
                )
                Spacer(Modifier.width(8.dp))
                Text(
                    text = "DESAFIO DO DIA",
                    color = TextoBranco,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
            }

            Column(modifier = Modifier.padding(20.dp)) {

                Text(
                    text = titulo.uppercase(),
                    color = TextoBranco,
                    fontSize = 26.sp,
                    fontWeight = FontWeight.ExtraBold
                )

                Spacer(Modifier.height(8.dp))

                Text(
                    text = descricao,
                    color = TextoBranco,
                    fontSize = 14.sp
                )

                Spacer(Modifier.height(20.dp))

                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(14.dp))
                        .background(BotaoEntrarFundo)
                        .clickable { aoComecar() }
                        .padding(horizontal = 20.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Filled.PlayArrow,
                        contentDescription = null,
                        tint = TextoBranco
                    )
                    Spacer(Modifier.width(8.dp))
                    Text(
                        text = "COMEÇAR",
                        color = TextoBranco,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )
                }
            }
        }
    }
}
