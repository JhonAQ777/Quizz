package com.example.quizzapp.ui.screens.login


import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Email
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel

import com.example.quizzapp.ui.components.BotaoLogin
import com.example.quizzapp.ui.components.CampoComRotulo

import com.example.quizzapp.ui.theme.BotaoCriarContaFundo
import com.example.quizzapp.ui.theme.BotaoEntrarFundo
import com.example.quizzapp.ui.theme.FundoLogin
import com.example.quizzapp.ui.theme.TextoBotaoCriarConta
import com.example.quizzapp.ui.theme.TextoBotaoEntrar
import com.example.quizzapp.ui.theme.TextoErroLogin


/**
 * Tela de Login (versão oficial - fundo claro).
 * Cuida somente da UI e do estado dos campos (por meio do ControleLogin).
 *
 * Este design não usa logo nem título: só rótulo + campo de e-mail,
 * rótulo + campo de senha, botão "LOG IN" e botão "CREATE ACCOUNT".
 *
 * aoLoginComSucesso / aoEsquecerSenha / aoCriarConta são callbacks que
 * recebem de fora (normalmente do seu NavHost/Navigation). É aí que você
 * conecta a navegação real e, no caso de aoLoginComSucesso, seu sistema
 * de autenticação (veja a observação 🔒 dentro do composable e em
 * ControleLogin.kt).
 *
 * OBS: este design não tem um link visível de "Forgot your password?",
 * então aoEsquecerSenha fica disponível como parâmetro para quando você
 * quiser adicionar esse link depois, mas não é chamado neste layout.
 */
@Preview(apiLevel = 37)
@Composable
fun TelaLogin(

    controleLogin: ControleLogin = viewModel(),

    aoLoginComSucesso: () -> Unit = {},


    aoCriarConta: () -> Unit = {}

) {

    val estadoTela = controleLogin.estadoTela


    Box(

        modifier = Modifier
            .fillMaxSize()
            .background(FundoLogin)

    ) {

        Column(

            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(
                    rememberScrollState()
                )
                .padding(horizontal = 24.dp),

            verticalArrangement = Arrangement.Center

        ) {

            // Campo de e-mail.

            CampoComRotulo(

                rotulo = "EMAIL",

                valor = estadoTela.email,

                aoAlterarValor =
                    controleLogin::alterarEmail,

                textoPlaceholder = "username",

                iconeEsquerdo =
                    Icons.Outlined.Email
            )


            Spacer(
                Modifier.height(20.dp)
            )


            // Campo de senha.

            CampoComRotulo(

                rotulo = "PASSWORD",

                valor = estadoTela.senha,

                aoAlterarValor =
                    controleLogin::alterarSenha,

                textoPlaceholder = "",

                iconeEsquerdo =
                    Icons.Outlined.Lock,

                ehSenha = true,

                senhaVisivel =
                    estadoTela.senhaVisivel,

                aoAlternarVisibilidadeSenha =
                    controleLogin::alternarVisibilidadeSenha
            )


            estadoTela.mensagemErro?.let { erro ->

                Spacer(
                    Modifier.height(8.dp)
                )

                Text(
                    text = erro,
                    color = TextoErroLogin,
                    fontSize = 13.sp
                )
            }


            Spacer(
                Modifier.height(28.dp)
            )


            // Botão "LOG IN" (laranja).

            BotaoLogin(

                texto =
                    if (estadoTela.carregando)
                        "Carregando..."
                    else
                        "LOG IN",

                aoClicar = {

                    // 🔒 AQUI É DISPARADO O LOGIN.
                    // controleLogin.entrar(...) atualmente não faz nada real;
                    // você deve completar a função entrar() em
                    // ControleLogin.kt com sua lógica de autenticação real.

                    controleLogin.entrar(
                        aoSucesso =
                            aoLoginComSucesso
                    )
                },

                corFundo = BotaoEntrarFundo,

                corTexto = TextoBotaoEntrar,

                habilitado = !estadoTela.carregando
            )


            Spacer(
                Modifier.height(16.dp)
            )


            // Botão "CREATE ACCOUNT" (branco).

            BotaoLogin(

                texto = "CREATE ACCOUNT",

                aoClicar = {
                    // 🔒 Aqui você navega para a tela de cadastro
                    // (isso já chega de fora via aoCriarConta).
                    aoCriarConta()
                },

                corFundo = BotaoCriarContaFundo,

                corTexto = TextoBotaoCriarConta
            )
        }
    }
}
