package com.example.quizzapp.ui.screens.login


import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.quizzapp.data.remoto.ClienteSupabase
import com.example.quizzapp.data.repositorio.RepositorioAutenticacao
import kotlinx.coroutines.launch


/**
 * Estado da UI do login.
 * Apenas dados, sem lógica de negócio.
 */

data class EstadoLogin(

    val email: String = "",

    val senha: String = "",

    val senhaVisivel: Boolean = false,

    val carregando: Boolean = false,

    val mensagemErro: String? = null
)


/**
 * ViewModel da tela de login.
 * Já conectado ao Supabase Auth via RepositorioAutenticacao.
 */

class ControleLogin(

    private val repositorioAutenticacao: RepositorioAutenticacao = RepositorioAutenticacao()

) : ViewModel() {


    var estadoTela by mutableStateOf(
        EstadoLogin()
    )

        private set


    fun alterarEmail(
        novoEmail: String
    ) {

        estadoTela =
            estadoTela.copy(

                email = novoEmail,

                mensagemErro = null
            )
    }


    fun alterarSenha(
        novaSenha: String
    ) {

        estadoTela =
            estadoTela.copy(

                senha = novaSenha,

                mensagemErro = null
            )
    }


    fun alternarVisibilidadeSenha() {

        estadoTela =
            estadoTela.copy(

                senhaVisivel =
                    !estadoTela.senhaVisivel
            )
    }


    /**
     * Faz login no Supabase com e-mail e senha.
     * Em caso de sucesso, chama aoSucesso() (a TelaLogin usa isso pra navegar
     * pra tela principal, veja GrafoNavegacao.kt).
     */

    fun entrar(
        aoSucesso: () -> Unit
    ) {

        if (estadoTela.email.isBlank() || estadoTela.senha.isBlank()) {

            estadoTela = estadoTela.copy(
                mensagemErro = "Please fill in your email and password."
            )

            return
        }

        estadoTela = estadoTela.copy(
            carregando = true,
            mensagemErro = null
        )

        viewModelScope.launch {

            val resultado = repositorioAutenticacao.entrar(
                email = estadoTela.email,
                senha = estadoTela.senha
            )

            estadoTela = estadoTela.copy(carregando = false)

            resultado
                .onSuccess {
                    aoSucesso()
                }
                .onFailure { erro ->

                    estadoTela = estadoTela.copy(
                        mensagemErro = erro.message ?: "Could not log in. Please try again."
                    )
                }
        }
    }
}

