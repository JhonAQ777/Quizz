package com.example.quizzapp.data.repositorio

import com.example.quizzapp.data.remoto.ClienteSupabase
import io.github.jan.supabase.auth.auth
import io.github.jan.supabase.auth.providers.builtin.Email
import io.github.jan.supabase.auth.user.UserInfo
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put

/**
 * Fala com o Supabase Auth. Login e Home usam este repositório
 * (via ControleLogin e ControleCriarConta) para não terem que
 * conhecer os detalhes do supabase-kt.
 */
class RepositorioAutenticacao {

    private val auth = ClienteSupabase.instancia.auth

    /**
     * Cria a conta no Supabase Auth. O nome vai como metadado
     * ("nome_usuario") e o trigger trg_criar_perfil usa isso para
     * criar a linha correspondente em "perfis" automaticamente.
     *
     * Não faz login automático de propósito: depois de cadastrar,
     * o usuário é levado de volta para a TelaLogin.
     */
    suspend fun cadastrar(nome: String, email: String, senha: String): Result<Unit> {
        return try {
            auth.signUpWith(Email) {
                this.email = email
                this.password = senha
                data = buildJsonObject {
                    put("nome_usuario", nome)
                }
            }
            Result.success(Unit)
        } catch (erro: Exception) {
            Result.failure(erro)
        }
    }

    /**
     * Faz login com e-mail e senha. Se der certo, o supabase-kt já
     * guarda a sessão automaticamente (fica salva entre as telas).
     */
    suspend fun entrar(email: String, senha: String): Result<Unit> {
        return try {
            auth.signInWith(Email) {
                this.email = email
                this.password = senha
            }
            Result.success(Unit)
        } catch (erro: Exception) {
            Result.failure(erro)
        }
    }

    /** Usuário autenticado no momento, ou null se ninguém estiver logado. */
    fun usuarioAtual(): UserInfo? = auth.currentUserOrNull()

    suspend fun deslogar() {
        auth.signOut()
    }
}
