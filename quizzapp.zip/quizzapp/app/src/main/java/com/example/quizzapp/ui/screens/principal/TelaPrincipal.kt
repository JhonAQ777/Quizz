package com.example.quizzapp.ui.screens.principal

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding

import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel

import com.example.quizzapp.ui.screens.principal.componentes.BarraNavegacaoInferior
import com.example.quizzapp.ui.screens.principal.componentes.CabecalhoBoasVindas
import com.example.quizzapp.ui.screens.principal.componentes.CartaoDesafioDoDia
import com.example.quizzapp.ui.screens.principal.componentes.CartaoDisciplina
import com.example.quizzapp.ui.screens.principal.componentes.estiloParaMateria

import com.example.quizzapp.ui.theme.FundoLogin
import com.example.quizzapp.ui.theme.RoxoPrincipal
import com.example.quizzapp.ui.theme.TextoTituloPrincipal

/**
 * Tela principal (menu com as matérias). Cuida só da UI — quem busca
 * os dados (nome do usuário, lista de matérias) é o ControlePrincipal.
 *
 * Os cartões de matéria e os itens da barra inferior ainda não navegam
 * pra lugar nenhum (essas telas não existem ainda), mas já ficam
 * prontos com um aoClicar esperando a navegação futura.
 */
@Composable
fun TelaPrincipal(
    controlePrincipal: ControlePrincipal = viewModel()
) {
    val estadoTela = controlePrincipal.estadoTela

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(FundoLogin)
    ) {

        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
        ) {

            Spacer(Modifier.height(24.dp))

            CabecalhoBoasVindas(nomeUsuario = estadoTela.nomeUsuario)

            Spacer(Modifier.height(24.dp))

            CartaoDesafioDoDia(
                aoComecar = { /* TODO: navegar pro quiz em destaque quando a tela existir */ }
            )

            Spacer(Modifier.height(28.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "DISCIPLINAS",
                    color = TextoTituloPrincipal,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.ExtraBold
                )

                Row(
                    modifier = Modifier
                        .background(
                            com.example.quizzapp.ui.theme.CampoFundoLogin,
                            RoundedCornerShape(12.dp)
                        )
                        .clickable { /* TODO: navegar pra tela de Ranking quando existir */ }
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Filled.EmojiEvents,
                        contentDescription = null,
                        tint = RoxoPrincipal,
                        modifier = Modifier.height(18.dp)
                    )
                    Spacer(Modifier.width(6.dp))
                    Text(
                        text = "VER RANKING",
                        color = RoxoPrincipal,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(Modifier.height(16.dp))

            // Grade 2x2 com as matérias vindas do Supabase (tabela "materias").
            estadoTela.materias.chunked(2).forEach { linha ->

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    linha.forEach { materia ->
                        CartaoDisciplina(
                            titulo = materia.nome,
                            descricao = materia.descricao,
                            estilo = estiloParaMateria(materia.nome),
                            aoClicar = { /* TODO: navegar pro quiz da matéria quando a tela existir */ },
                            modificador = Modifier.weight(1f)
                        )
                    }

                    // Se a linha tiver só 1 item (número ímpar de matérias),
                    // preenche o espaço vazio pra não esticar o cartão.
                    if (linha.size == 1) {
                        Spacer(Modifier.weight(1f))
                    }
                }

                Spacer(Modifier.height(14.dp))
            }

            Spacer(Modifier.height(12.dp))
        }

        // Barra inferior fixa, fora da área de scroll.
        Column(modifier = Modifier.padding(16.dp)) {
            BarraNavegacaoInferior()
        }
    }
}
