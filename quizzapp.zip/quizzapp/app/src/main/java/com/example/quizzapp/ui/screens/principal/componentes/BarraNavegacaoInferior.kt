package com.example.quizzapp.ui.screens.principal.componentes

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

import com.example.quizzapp.ui.theme.BordaCampoLogin
import com.example.quizzapp.ui.theme.CampoFundoLogin
import com.example.quizzapp.ui.theme.RoxoPrincipal
import com.example.quizzapp.ui.theme.TextoRotuloLogin

/**
 * Barra inferior com 4 acessos: Quests, Ranking, Mapa, Perfil.
 * Os ícones aqui são padrão do Material — se você tiver ícones no
 * mesmo estilo pixelado do resto do app, troque cada Icon por
 * Image(painter = painterResource(...)).
 *
 * Nenhum item navega pra lugar nenhum ainda (aoClicar fica pronto
 * pra você conectar quando essas telas existirem).
 */
@Composable
fun BarraNavegacaoInferior(
    modificador: Modifier = Modifier
) {
    Row(
        modifier = modificador
            .fillMaxWidth()
            .background(CampoFundoLogin, RoundedCornerShape(20.dp))
            .border(1.dp, BordaCampoLogin, RoundedCornerShape(20.dp))
            .padding(vertical = 14.dp),
        horizontalArrangement = androidx.compose.foundation.layout.Arrangement.SpaceEvenly
    ) {
        ItemBarraNavegacao(icone = Icons.Filled.SportsEsports, rotulo = "QUESTS", aoClicar = { /* TODO: navegar pra tela de Quests */ })
        ItemBarraNavegacao(icone = Icons.Filled.EmojiEvents, rotulo = "RANKING", aoClicar = { /* TODO: navegar pra tela de Ranking */ })
        ItemBarraNavegacao(icone = Icons.Filled.Map, rotulo = "MAPA", aoClicar = { /* TODO: navegar pra tela de Mapa */ })
        ItemBarraNavegacao(icone = Icons.Filled.Person, rotulo = "PERFIL", aoClicar = { /* TODO: navegar pra tela de Perfil */ })
    }
}

@Composable
private fun ItemBarraNavegacao(
    icone: ImageVector,
    rotulo: String,
    aoClicar: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.clickable { aoClicar() }
    ) {
        Icon(imageVector = icone, contentDescription = rotulo, tint = RoxoPrincipal)
        Text(text = rotulo, color = TextoRotuloLogin, fontSize = 10.sp)
    }
}
