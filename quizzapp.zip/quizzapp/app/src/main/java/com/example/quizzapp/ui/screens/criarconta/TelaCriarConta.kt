package com.example.quizzapp.ui.screens.criarconta

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.outlined.Email
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel

import com.example.quizzapp.ui.components.BotaoLogin
import com.example.quizzapp.ui.components.CampoComRotulo

import com.example.quizzapp.ui.theme.BordaCampoLogin
import com.example.quizzapp.ui.theme.BotaoEntrarFundo
import com.example.quizzapp.ui.theme.FundoLogin
import com.example.quizzapp.ui.theme.TextoBotaoEntrar
import com.example.quizzapp.ui.theme.TextoCampoLogin
import com.example.quizzapp.ui.theme.TextoErroLogin
import com.example.quizzapp.ui.theme.TextoPlaceholderLogin
import com.example.quizzapp.ui.theme.TextoRotuloLogin

/**
 * Tela de criar conta (em inglês, igual à tela de login).
 * Cuida somente da UI e do estado dos campos (por meio do ControleCriarConta).
 *
 * aoContaCriada / aoVoltar / aoIrParaLogin são callbacks que recebem de
 * fora (do GrafoNavegacao). Depois de criar a conta com sucesso, o app
 * volta pra tela de login (aoContaCriada), não faz login automático.
 */
@Composable
fun TelaCriarConta(
    controleCriarConta: ControleCriarConta = viewModel(),
    aoContaCriada: () -> Unit = {},
    aoVoltar: () -> Unit = {},
    aoIrParaLogin: () -> Unit = {}
) {

    val estadoTela = controleCriarConta.estadoTela

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(FundoLogin)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 24.dp)
    ) {

        Spacer(Modifier.height(24.dp))

        // Seta para voltar pra tela de login.
        Icon(
            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
            contentDescription = "Back",
            tint = TextoCampoLogin,
            modifier = Modifier
                .size(28.dp)
                .clickable { aoVoltar() }
        )

        Spacer(Modifier.height(20.dp))

        Text(
            text = "CREATE ACCOUNT",
            color = TextoCampoLogin,
            fontSize = 26.sp,
            fontWeight = FontWeight.ExtraBold,
            letterSpacing = 1.sp
        )

        Spacer(Modifier.height(4.dp))

        Text(
            text = "Fill in your details to get started.",
            color = TextoRotuloLogin,
            fontSize = 14.sp
        )

        Spacer(Modifier.height(28.dp))

        // Campo de nome.
        CampoComRotulo(
            rotulo = "NAME",
            valor = estadoTela.nome,
            aoAlterarValor = controleCriarConta::alterarNome,
            textoPlaceholder = "Your full name",
            iconeEsquerdo = Icons.Outlined.Person
        )

        Spacer(Modifier.height(20.dp))

        // Campo de e-mail.
        CampoComRotulo(
            rotulo = "EMAIL",
            valor = estadoTela.email,
            aoAlterarValor = controleCriarConta::alterarEmail,
            textoPlaceholder = "name@example.com",
            iconeEsquerdo = Icons.Outlined.Email
        )

        Spacer(Modifier.height(20.dp))

        // Campo de senha.
        CampoComRotulo(
            rotulo = "PASSWORD",
            valor = estadoTela.senha,
            aoAlterarValor = controleCriarConta::alterarSenha,
            textoPlaceholder = "",
            iconeEsquerdo = Icons.Outlined.Lock,
            ehSenha = true,
            senhaVisivel = estadoTela.senhaVisivel,
            aoAlternarVisibilidadeSenha = controleCriarConta::alternarVisibilidadeSenha
        )

        Spacer(Modifier.height(20.dp))

        // Campo de confirmar senha.
        CampoComRotulo(
            rotulo = "CONFIRM PASSWORD",
            valor = estadoTela.confirmarSenha,
            aoAlterarValor = controleCriarConta::alterarConfirmarSenha,
            textoPlaceholder = "",
            iconeEsquerdo = Icons.Outlined.Lock,
            ehSenha = true,
            senhaVisivel = estadoTela.confirmarSenhaVisivel,
            aoAlternarVisibilidadeSenha = controleCriarConta::alternarVisibilidadeConfirmarSenha
        )

        estadoTela.mensagemErro?.let { erro ->
            Spacer(Modifier.height(8.dp))
            Text(text = erro, color = TextoErroLogin, fontSize = 13.sp)
        }

        Spacer(Modifier.height(28.dp))

        // Botão "CREATE ACCOUNT" (laranja).
        BotaoLogin(
            texto = if (estadoTela.carregando) "Creating..." else "CREATE ACCOUNT",
            aoClicar = {
                // 🔒 Aqui é disparado o cadastro. controleCriarConta.cadastrar(...)
                // já chama o Supabase de verdade (veja RepositorioAutenticacao.kt).
                controleCriarConta.cadastrar(aoSucesso = aoContaCriada)
            },
            corFundo = BotaoEntrarFundo,
            corTexto = TextoBotaoEntrar,
            habilitado = !estadoTela.carregando
        )

        Spacer(Modifier.height(20.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center
        ) {
            Text(
                text = "Already have an account? ",
                color = TextoRotuloLogin,
                fontSize = 14.sp
            )
            Text(
                text = "Log in",
                color = BotaoEntrarFundo,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.clickable { aoIrParaLogin() }
            )
        }

        Spacer(Modifier.height(40.dp))
    }
}
