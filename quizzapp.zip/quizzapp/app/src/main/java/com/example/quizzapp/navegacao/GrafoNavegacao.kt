package com.example.quizzapp.navegacao

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.quizzapp.ui.screens.criarconta.TelaCriarConta
import com.example.quizzapp.ui.screens.login.TelaLogin
import com.example.quizzapp.ui.screens.principal.TelaPrincipal

/**
 * Grafo de navegação do app. Todo mundo começa na tela de Login.
 *
 * Fluxo:
 * Login --(criar conta)--> CriarConta --(conta criada)--> volta pro Login
 * Login --(login ok)--> Principal (limpa o back stack, não dá pra "voltar" pro login)
 */
@Composable
fun GrafoNavegacao(
    controladorNavegacao: NavHostController = rememberNavController()
) {
    NavHost(
        navController = controladorNavegacao,
        startDestination = Rotas.LOGIN
    ) {

        composable(Rotas.LOGIN) {
            TelaLogin(
                aoLoginComSucesso = {
                    controladorNavegacao.navigate(Rotas.PRINCIPAL) {
                        // Remove a tela de login do back stack: ao apertar
                        // "voltar" na tela principal, o app não retorna pro login.
                        popUpTo(Rotas.LOGIN) { inclusive = true }
                    }
                },

                aoCriarConta = {
                    controladorNavegacao.navigate(Rotas.CRIAR_CONTA)
                }
            )
        }

        composable(Rotas.CRIAR_CONTA) {
            TelaCriarConta(
                aoContaCriada = {
                    // Conta criada -> volta pro login pra fazer login "de verdade".
                    controladorNavegacao.popBackStack()
                },
                aoVoltar = {
                    controladorNavegacao.popBackStack()
                },
                aoIrParaLogin = {
                    controladorNavegacao.popBackStack()
                }
            )
        }

        composable(Rotas.PRINCIPAL) {
            TelaPrincipal()
        }
    }
}


