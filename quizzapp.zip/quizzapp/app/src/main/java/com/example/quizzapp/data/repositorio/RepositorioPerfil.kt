package com.example.quizzapp.data.repositorio

import com.example.quizzapp.data.modelo.Perfil
import com.example.quizzapp.data.remoto.ClienteSupabase
import io.github.jan.supabase.auth.auth
import io.github.jan.supabase.postgrest.from

/**
 * Busca dados da tabela "perfis" (por enquanto, só o nome do usuário
 * para o "Olá, {nome}!" da TelaPrincipal).
 *
 * 🔒 Isso depende de existir uma policy de RLS que deixe o usuário
 * ler a própria linha em "perfis" (ex: usando_expression = auth.uid() = id).
 * Se sua policy ainda não permite isso, adicione-a no Supabase.
 */
class RepositorioPerfil {

    private val supabase = ClienteSupabase.instancia

    suspend fun buscarPerfilAtual(): Result<Perfil> {
        return try {
            val idUsuario = supabase.auth.currentUserOrNull()?.id
                ?: return Result.failure(IllegalStateException("Nenhum usuário logado."))

            val perfil = supabase
                .from("perfis")
                .select {
                    filter {
                        eq("id", idUsuario)
                    }
                }
                .decodeSingle<Perfil>()

            Result.success(perfil)
        } catch (erro: Exception) {
            Result.failure(erro)
        }
    }
}
