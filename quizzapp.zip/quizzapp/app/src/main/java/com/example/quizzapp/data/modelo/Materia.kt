package com.example.quizzapp.data.modelo

import kotlinx.serialization.Serializable

/**
 * Representa uma linha da tabela "materias" no Supabase
 * (Física, História, Português, Matemática, e as que você adicionar depois).
 *
 * ⚠️ Ajuste os nomes dos campos para bater com as colunas reais da sua
 * tabela "materias". id/nome/descricao são um formato comum, mas confira
 * no seu schema.
 */
@Serializable
data class Materia(
    val id: String,
    val nome: String,
    val descricao: String
)
