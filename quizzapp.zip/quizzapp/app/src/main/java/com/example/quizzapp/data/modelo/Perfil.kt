package com.example.quizzapp.data.modelo

import kotlinx.serialization.Serializable

/**
 * Representa uma linha da tabela "perfis" no Supabase.
 *
 * ⚠️ Ajuste os nomes dos campos aqui para bater exatamente com as colunas
 * da sua tabela "perfis" (id e nome_usuario já seguem o padrão combinado
 * no trigger trg_criar_perfil). Se você tiver mais colunas lá
 * (ex: pontuacao_total), adicione-as aqui também.
 */
@Serializable
data class Perfil(
    val id: String,
    val nome_usuario: String
)
